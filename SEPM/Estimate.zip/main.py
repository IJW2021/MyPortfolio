# pylint: disable=missing-module-docstring
# pylint: disable=missing-class-docstring
# pylint: disable=missing-function-docstring

# =============================
# Basic COCOMO Calculator
# ============================
import platform
import time
import sys
from datetime import datetime
from dateutil.relativedelta import relativedelta
from typing import NoReturn

# Set Start Time
start_time = time.time()


def basic_cocomo(loc: int) -> NoReturn:
    """
    Calculate Based on the COCOMO Methof
    :param loc: Lines of Code
    :return: None
    """
    global MODEL
    effort, time_needed, developers = 0, 0, 0
    # Models
    cocomo_models: list[tuple[str, list[float]]] = [("Organic", [2.4, 1.05, 2.5, 0.38]), ("Semi-Detached", [3.0, 1.12, 2.5, 0.35]), ("Embedded", [3.6, 1.20, 2.5, 0.32])]  # noqa: E501

    if isinstance(loc, int):
        lines_of_code: int = loc
    else:
        raise TypeError
    # Set the Model we are using Organic etc based on lines of code
    if 2 <= lines_of_code / 1000 <= 50:
        MODEL = cocomo_models[0]
    elif 50 < lines_of_code / 1000 <= 300:
        MODEL = cocomo_models[1]
    elif 300 > lines_of_code / 1000:
        MODEL = cocomo_models[2]
    try:
        # Actual Calculations used to produce the Final Answers
        # Use ** rather then MODEL[1][0]*Pow(lines_of_code / 0x3E8,MODEL[1][1]) as performance is slighty better
        # as we dont need to make a function call
        effort: float = MODEL[1][0] * (lines_of_code / 0x3E8) ** MODEL[1][1]
        time_needed: float = MODEL[1][2] * (effort ** MODEL[1][3])
        developers: float = effort / time_needed
    except UnboundLocalError:
        print("Input Value Cannot be Processed")

    if all(list(map(lambda x: isinstance(x, float), [effort, time_needed, developers]))):  # noqa: E501
        print("\033[95m" + chr(0x2A) * 0x50)
        print("\033[94mCOCOMO Basic Calculator V1.0 Ian Wolloff July 2022")
        print(f"\033[94mPython Version: {platform.python_version()} Platform: {platform.system()} CPU Architecture: {platform.processor().upper()}")  # noqa: E501
        print(f"\033[94mProgram Execution Time: {str(round(time.time() - start_time,6))} Seconds")  # noqa: E501
        print(f"\033[92mLines of code\033[96m {lines_of_code}")
        print(f"\033[92mThe Model is \033[96m{MODEL[0]}")
        print(f"\033[92mModel Values used are \033[96m{MODEL[1]}")
        print(f"\033[92mCalculated Effort is \033[96m{round(effort)}\033[92m Person-Month")  # noqa: E501
        print(f"\033[92mCalculated Time is \033[96m{round(time_needed)} \033[92mMonths from current date : \033[96m {datetime.now() + relativedelta(months=+round(time_needed)):%d/%m/%Y}")  # noqa: E501
        print(f"\033[92mDevelopers needed \033[96m{round(developers)}")
        print("\033[95m" + chr(0x2A) * 0x50)
    else:
        print("Calculation Error")


# Get LOC Value from Commandline
if len(sys.argv) > 1:
    try:
        basic_cocomo(loc=int(sys.argv[1]))
    except ValueError:
        print("Invalid LOC Value")
else:
    basic_cocomo(loc=3000)
